<?php
        // Please do not edit here
$smtph = 'smtp.hostinger.in';
$usrnm = 'no-reply@makes360.in';
$passwd = 'Adsfdgf@ankit_sir0';
$xprt = '587';
$frme = 'no-reply@makes360.in'
?>